<?php if (isset($component)) { $__componentOriginalb04edb52fb36cc872b2c7004498f11e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb04edb52fb36cc872b2c7004498f11e7 = $attributes; } ?>
<?php $component = App\View\Components\DetailsLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('details-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DetailsLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'space-y-6 dark:bg-zinc-800 dark:text-white']); ?>
    <h1 class="font-bold text-xl">Add Movie Details</h1>

    <form action="<?php echo e(route('movies.store')); ?>" method="post" enctype="multipart/form-data"
        class="mt-6 space-y-8 divide-y divide-gray-200 dark:divide-zinc-700">
        <?php echo csrf_field(); ?>
        <div class="flex justify-evenly">
            <div class="space-y-6 sm:space-y-5">
                <div class="sm:grid sm:grid-cols-1 sm:gap-4 sm:items-start sm:pt-5">
                    <label for="title"
                        class="block text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Title
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>"
                            class="p-2  border block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>
                <div>
                    <label for="description"
                        class="block p-2 text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Description
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <textarea name="description" id="description" rows="3"
                            class="p-2  border block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>
                <div>
                    <label for="release_date"
                        class="block text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Release Date
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <input type="date" name="release_date" id="release_date" value="<?php echo e(old('release_date')); ?>"
                            class="p-2  border block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>
                <div class="pt-5 ">
                    <div class="flex justify-start">
                        <button type="submit"
                            class=" w-full inline-flex justify-center py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            Create
                        </button>
                    </div>
                </div>
            </div>

            <div class="space-y-6 sm:space-y-5">
                <div class="sm:grid sm:grid-cols-1 sm:gap-4 sm:items-start sm:pt-5">
                    <label for="duration"
                        class="block text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Duration
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <input type="number" name="duration" id="duration" value="<?php echo e(old('duration')); ?>"
                            class="p-2  border block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>
                <div>
                    <label for="genre"
                        class="block text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Genre
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <input type="text" name="genre" id="genre" value="<?php echo e(old('genre')); ?>"
                            class="p-2  border block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>
                <div>
                    <label for="director"
                        class="block text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Director
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <input type="text" name="director" id="director" value="<?php echo e(old('director')); ?>"
                            class="p-2  border block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>
                <div>
                    <label for="poster_image"
                        class="block text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Poster Image
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <input type="file" name="poster_image" id="poster_image" accept="image/*"
                            class="block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>
                <div>
                    <label for="trailer_url"
                        class="block text-sm font-medium text-gray-700 dark:text-white sm:mt-px sm:pt-2">
                        Trailer URL
                    </label>
                    <div class="mt-1 sm:mt-0 sm:col-span-2">
                        <input type="url" name="trailer_url" id="trailer_url" value="<?php echo e(old('trailer_url')); ?>"
                            class="p-2  border block w-full max-w-lg border-gray-300 dark:border-zinc-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>
            </div>
        </div>


    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb04edb52fb36cc872b2c7004498f11e7)): ?>
<?php $attributes = $__attributesOriginalb04edb52fb36cc872b2c7004498f11e7; ?>
<?php unset($__attributesOriginalb04edb52fb36cc872b2c7004498f11e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb04edb52fb36cc872b2c7004498f11e7)): ?>
<?php $component = $__componentOriginalb04edb52fb36cc872b2c7004498f11e7; ?>
<?php unset($__componentOriginalb04edb52fb36cc872b2c7004498f11e7); ?>
<?php endif; ?>
<?php /**PATH D:\Work\Works\Websites\in_progress\cg_chartbuster\resources\views/movies/create.blade.php ENDPATH**/ ?>