<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" :class="isDark ? 'dark' : 'light'" x-data="{ isDark: false }">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>


<body class="font-montserrat text-sm bg-white dark:bg-zinc-900 ">
    <div
        class="flex min-h-screen  2xl:max-w-screen-2xl 2xl:mx-auto 2xl:border-x-2 2xl:border-gray-200 dark:2xl:border-zinc-700 ">
        <!-- Left Sidebar -->
        <?php if (isset($component)) { $__componentOriginal317f6d258974dd0d4c826f46be532009 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal317f6d258974dd0d4c826f46be532009 = $attributes; } ?>
<?php $component = App\View\Components\LeftSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('left-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LeftSidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal317f6d258974dd0d4c826f46be532009)): ?>
<?php $attributes = $__attributesOriginal317f6d258974dd0d4c826f46be532009; ?>
<?php unset($__attributesOriginal317f6d258974dd0d4c826f46be532009); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal317f6d258974dd0d4c826f46be532009)): ?>
<?php $component = $__componentOriginal317f6d258974dd0d4c826f46be532009; ?>
<?php unset($__componentOriginal317f6d258974dd0d4c826f46be532009); ?>
<?php endif; ?>
        <!-- /Left Sidebar -->

        <main class=" flex-1 py-10  px-5 sm:px-10 " x-data="{ isActive: 'movies' }">
            <?php if (isset($component)) { $__componentOriginal82ec74fa20f98b440c243186f16ef573 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal82ec74fa20f98b440c243186f16ef573 = $attributes; } ?>
<?php $component = App\View\Components\MobileNavbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mobile-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MobileNavbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal82ec74fa20f98b440c243186f16ef573)): ?>
<?php $attributes = $__attributesOriginal82ec74fa20f98b440c243186f16ef573; ?>
<?php unset($__attributesOriginal82ec74fa20f98b440c243186f16ef573); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal82ec74fa20f98b440c243186f16ef573)): ?>
<?php $component = $__componentOriginal82ec74fa20f98b440c243186f16ef573; ?>
<?php unset($__componentOriginal82ec74fa20f98b440c243186f16ef573); ?>
<?php endif; ?>

            

            
            <?php echo e($slot); ?>

            

        </main>

        <!-- Right Sidebar -->
        <?php if (isset($component)) { $__componentOriginal549c801c7f1aa8e744e41e09f80f1d6e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c801c7f1aa8e744e41e09f80f1d6e = $attributes; } ?>
<?php $component = App\View\Components\RightSidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('right-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\RightSidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c801c7f1aa8e744e41e09f80f1d6e)): ?>
<?php $attributes = $__attributesOriginal549c801c7f1aa8e744e41e09f80f1d6e; ?>
<?php unset($__attributesOriginal549c801c7f1aa8e744e41e09f80f1d6e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c801c7f1aa8e744e41e09f80f1d6e)): ?>
<?php $component = $__componentOriginal549c801c7f1aa8e744e41e09f80f1d6e; ?>
<?php unset($__componentOriginal549c801c7f1aa8e744e41e09f80f1d6e); ?>
<?php endif; ?>
        <!-- /Right Sidebar -->

    </div>

</body>

</html>
<?php /**PATH D:\Work\Works\Websites\in_progress\cg_chartbuster\resources\views/layout/details-layout.blade.php ENDPATH**/ ?>