<?php if (isset($component)) { $__componentOriginalb04edb52fb36cc872b2c7004498f11e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb04edb52fb36cc872b2c7004498f11e7 = $attributes; } ?>
<?php $component = App\View\Components\DetailsLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('details-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DetailsLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    all movies

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb04edb52fb36cc872b2c7004498f11e7)): ?>
<?php $attributes = $__attributesOriginalb04edb52fb36cc872b2c7004498f11e7; ?>
<?php unset($__attributesOriginalb04edb52fb36cc872b2c7004498f11e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb04edb52fb36cc872b2c7004498f11e7)): ?>
<?php $component = $__componentOriginalb04edb52fb36cc872b2c7004498f11e7; ?>
<?php unset($__componentOriginalb04edb52fb36cc872b2c7004498f11e7); ?>
<?php endif; ?>
<?php /**PATH D:\Work\Works\Websites\in_progress\cg_chartbuster\resources\views/movies/index.blade.php ENDPATH**/ ?>