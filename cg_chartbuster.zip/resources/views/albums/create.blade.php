<x-details-layout>
    <h1 class="text-3xl font-semibold">{{ Route::currentRouteName() }}</h1>

</x-details-layout>
