<x-details-layout>
    <h1 class="text-3xl font-semibold">{{ Route::currentRouteName() }} - Movie: {{ $movie->title }}</h1>
</x-details-layout>
