<x-details-layout>
    all movies

</x-details-layout>
